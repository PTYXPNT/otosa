const ownermenu = (prefix) => { 
	return `
	
╔══✪〘 OWNER 〙✪══
║
╠➥ *${prefix}block 62858xxxxx*
╠➥ *${prefix}unblock 62858xxxxx*
╠➥ *${prefix}promote @tagmember*
╠➥ *${prefix}demote @tagadmin*
╠➥ *${prefix}bc*
╠➥ *${prefix}leave*
╠➥ *${prefix}bc2*
╠➥ *${prefix}leave*
╠➥ *${prefix}clearall*
╠➥ *${prefix}clone*
╠➥ *${prefix}hidetag*
╠➥ *${prefix}hidetag2*
╠➥ *${prefix}setprefix*
╠➥ *${prefix}unban*
╠➥ *${prefix}ban*
╠➥ *${prefix}runtime*
╠➥ *${prefix}turnoff*
╠➥ *${prefix}getses*
║
╚═〘  YU OTOSAKA BOT 〙`
}
exports.ownermenu = ownermenu