const kerangmenu = (prefix) => { 
	return `
╔══✪〘 KERANG 〙✪══
║
╠➥ *${prefix}apakah*
╠➥ *${prefix}rate*
╠➥ *${prefix}bisakah*
╠➥ *${prefix}kapankah*
╠➥ *${prefix}gantengcek*
╠➥ *${prefix}toxic*
╠➥ *${prefix}cantikcek*
╠➥ *${prefix}persengay*
║
╚═〘  YU OTOSAKA BOT 〙`
}
exports.kerangmenu = kerangmenu