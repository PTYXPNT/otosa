const help = (prefix) => { 
	return `

    ╭────COMANDOS──────
    ║╭─────────────────
    ║╠➣  *YU OTOSAKA BOT*
    ║╰───────────────── 
    ║╭───〘 *INFO*  〙─────
    ║╠-❥ *Yu otosakaツ* *Versi 9.9*
    ║╠-❥ *Owner : TANPA NAMA*
    ║╠-❥ *Link* : wa.me/6285343788098
    ║╠-❥ *Link* : wa.me/6281210893869
    ║╠-❥ *Link* : wa.me/6287884043364
    ║╠-❥ *Prefix : 「 ${prefix} 」*
    ║╠-❥ *Total Pengguna : 9999*   
    ║╰────────────────
    ║╭───LIST MENU──
    ║╠➣ *${prefix}ownermenu*
    ║╠➣ *${prefix}adminmenu*
    ║╠➣ *${prefix}groupmenu*
    ║╠➣ *${prefix}makermenu*
    ║╠➣ *${prefix}nsfwmenu*
    ║╠➣ *${prefix}listmenu*
    ║╠➣ *${prefix}funmenu*
    ║╠➣ *${prefix}mediamenu*
    ║╠➣ *${prefix}animemenu*
    ║╠➣ *${prefix}kerangmenu*
    ║╠➣ *${prefix}quotemaker*
    ║╠➣ *${prefix}vipmenu*
    ║╠➣ *${prefix}othermenu*
    ║╰───────────────
    ║╭─────OTHER────
    ║╠➣ *${prefix}bugreport*
    ║╠➣ *${prefix}info*
    ║╠➣ *${prefix}owner*
    ║╠➣ *${prefix}request*
    ║╠➣ *${prefix}setprefix*
    ║╠➣ *${prefix}listblock*
    ║╠➣ *${prefix}iklan*
    ║╠➣ *${prefix}runtume*
    ║╠➣ *${prefix}rules*
    ║╠➣ *${prefix}tnc*
    ║╠➣ *${prefix}cekvip*
    ║╠➣ *${prefix}daftarvip*
    ║╠➣ *${prefix}addvip*
    ║╠➣ *${prefix}dellvip*
    ║╠➣ *${prefix}snk*
    ║╠➣ *${prefix}listpremium*
    ║╠➣ *${prefix}donate*
    ║╠➣ *${prefix}fitnah*
    ║╠➣ *${prefix}totaluser*
    ║╠➣ *${prefix}level*
    ║╠➣ *${prefix}leveling*
    ║╠➣ *${prefix}addbacot*
    ║╠➣ *${prefix}bacotlist*
    ║╠➣ *${prefix}resetbacot*
    ║╠➣ *${prefix}glass*
    ║╰─────────────────
    ║╭─────CONTATO─────
    ║╠➣ Name : *YU OTOSAKAツ*
    ║╠➣Coded using *Nano* on Android
    ║║Termux
    ║╠➣ Request? 
    ║╠➣wa.me/6285343788098
    ║╠════
    ║║Advanced:
    ║║> return m
    ║╰─────────────────
    ║
    ┗━┅┄⟞⟦ *YU OTOSAKA* ⟧┉┉━┛`
}
exports.help = help
