const funmenu = (prefix) => { 
	return `
╔══✪〘 FUN 〙✪══
║
╠➥ *${prefix}tebakgambar*
╠➥ *${prefix}caklontong*
╠➥ *${prefix}family100*
╠➥ *${prefix}game*
╠➥ *${prefix}truth*
╠➥ *${prefix}dare*
╠➥ *${prefix}quotes*
╠➥ *${prefix}hilih*
╠➥ *${prefix}alay* 
╠➥ *${prefix}simi* 
╠➥ *${prefix}bucin*
╠➥ *${prefix}gtts* 
╠➥ *${prefix}tts*
║
╚═〘 YU OTOSAKA BOT 〙`
}
exports.funmenu = funmenu